# AgroTrace AI — Backend Prototype

This package is a small FastAPI backend designed to power the accompanying AgroTrace frontend.

It currently provides seeded demo data and validation-style responses for lots, allocation, settlement claims and audit verification. It does **not** deploy Solidity contracts, call QpiAI services or process real payments yet. Those integrations should replace the in-memory data in `app/main.py`.

## Run locally

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

The API is available at `http://127.0.0.1:8000` and Swagger documentation at `/docs`.

## Included routes

| Route | Purpose |
| --- | --- |
| `GET /health` | Prototype service and integration status |
| `GET /lots` | Seeded lot registry |
| `GET /lots/{lot_id}/lineage` | Lot ancestry and evidence reference |
| `POST /optimize/allocation` | Feasible demo allocation result |
| `GET /claims` | Open settlement claims |
| `POST /claims/validate` | Demonstrates duplicate/invoice/lineage rejection |
| `GET /audit/verify` | Demonstrates audit-head verification |

## Production next steps

1. Replace seeded lists with the event indexer and SQLite cache.
2. Connect routes to the Hardhat-deployed `AgroTrace.sol` contract through `web3.py`.
3. Persist evidence to IPFS or labelled local CAS.
4. Add real QpiAI adapters only after probing the installed SDK signatures; never represent a local fallback as a real QpiAI run.
