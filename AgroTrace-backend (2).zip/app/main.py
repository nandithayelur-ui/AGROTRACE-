from datetime import datetime, timezone
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel


app = FastAPI(
    title="AgroTrace AI API",
    version="0.1.0-prototype",
    description="Seeded prototype API for the AgroTrace procurement frontend.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:4173", "http://localhost:4173"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

LOTS = [
    {"id": "LOT-2026-084", "crop": "Wheat", "farmer": "Ravi", "origin": "Mandya", "weight_kg": 600, "grade": "A", "owner": "Mandya Warehouse", "status": "RECEIVED", "parent_id": "LOT-2026-071", "evidence_cid": "bafybei-demo-a47f"},
    {"id": "LOT-2026-085", "crop": "Wheat", "farmer": "Ravi", "origin": "Mandya", "weight_kg": 385, "grade": "A", "owner": "Mandya Warehouse", "status": "GRADED", "parent_id": "LOT-2026-071", "evidence_cid": "bafybei-demo-c109"},
    {"id": "LOT-2026-091", "crop": "Wheat", "farmer": "Meena", "origin": "Hassan", "weight_kg": 820, "grade": "B", "owner": "Suresh Collection", "status": "IN_TRANSIT", "parent_id": "LOT-2026-068", "evidence_cid": "bafybei-demo-e820"},
]

CLAIMS = [
    {"id": "CL-114", "lot_id": "LOT-2026-084", "invoice_id": "INV-8821", "amount_paise": 6840000, "status": "NEEDS_REVIEW"},
    {"id": "CL-116", "lot_id": "LOT-2026-085", "invoice_id": "INV-8824", "amount_paise": 4389000, "status": "VERIFIED"},
    {"id": "CL-117", "lot_id": "LOT-2026-084", "invoice_id": "INV-8821", "amount_paise": 6840000, "status": "CONFLICT"},
]


class ClaimValidationRequest(BaseModel):
    attack: Literal["duplicate", "invoice", "lineage"]


@app.get("/health")
def health():
    return {
        "status": "ok",
        "mode": "prototype_seeded_data",
        "services": {
            "chain": "not_connected",
            "ipfs": "not_connected",
            "qpiai_opt": "not_configured",
            "qpiai_qcloud": "not_configured",
        },
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/lots")
def list_lots():
    return {"items": LOTS, "total": len(LOTS)}


@app.get("/lots/{lot_id}/lineage")
def lot_lineage(lot_id: str):
    lot = next((lot for lot in LOTS if lot["id"] == lot_id), None)
    if not lot:
        raise HTTPException(status_code=404, detail="Lot not found")
    return {
        "lot": lot,
        "lineage": [
            {"id": lot["parent_id"], "event": "REGISTERED", "weight_kg": 1000},
            {"id": lot["id"], "event": "SPLIT_OR_TRANSFER", "weight_kg": lot["weight_kg"]},
        ],
        "mass_balance": {"valid": True, "message": "Seeded prototype validation passed"},
    }


@app.post("/optimize/allocation")
def optimize_allocation():
    return {
        "mode": "prototype_seeded_result",
        "solver": "not_invoked",
        "warning": "This result is demo data. Connect a verified solver before committing allocations.",
        "feasible": True,
        "estimated_value_paise": 42780000,
        "allocations": [
            {"lot_id": "LOT-2026-085", "contract_id": "C-208", "weight_kg": 385},
            {"lot_id": "LOT-2026-084", "contract_id": "C-211", "weight_kg": 600},
        ],
    }


@app.get("/claims")
def list_claims():
    return {"items": CLAIMS, "total": len(CLAIMS)}


@app.post("/claims/validate")
def validate_claim(payload: ClaimValidationRequest):
    rejection = {
        "duplicate": ("DuplicateSettlement", "LOT-2026-084 already has a settled claim."),
        "invoice": ("InvoiceAlreadyUsed", "Invoice INV-8821 is already linked to CL-114."),
        "lineage": ("AncestorAlreadySettled", "An ancestor of this lot has already been settled."),
    }
    code, reason = rejection[payload.attack]
    return {"accepted": False, "revert": code, "reason": reason, "mode": "prototype_validation"}


@app.get("/audit/verify")
def verify_audit():
    return {
        "valid": True,
        "audit_head": "0x81b7a3c2demo00000000000000000000000000000000000000000000e4f91d08",
        "events_checked": 186,
        "mode": "prototype_seeded_result",
    }
