"""AgroTrace backend prototype."""
