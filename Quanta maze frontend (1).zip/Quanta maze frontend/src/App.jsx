
import { useState } from 'react'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('Dashboard')
  const [lots, setLots] = useState([
    { id: 'LOT001', crop: 'Rice', quantity: 2000, grade: 'Grade A', status: 'Verified' },
    { id: 'LOT002', crop: 'Tomatoes', quantity: 800, grade: 'Pending', status: 'Inspection pending' },
    { id: 'LOT003', crop: 'Wheat', quantity: 1500, grade: 'Grade B', status: 'Verified' },
  ])
  const [showForm, setShowForm] = useState(false)
  const [crop, setCrop] = useState('Rice')
  const [quantity, setQuantity] = useState('')

  function registerLot(e) {
    e.preventDefault()
    if (!quantity || Number(quantity) <= 0) return

    setLots([
      ...lots,
      {
        id: `LOT${String(lots.length + 1).padStart(3, '0')}`,
        crop,
        quantity: Number(quantity),
        grade: 'Pending',
        status: 'Inspection pending',
      },
    ])
    setQuantity('')
    setShowForm(false)
    setActiveTab('Lots')
  }

  const totalQuantity = lots.reduce((sum, lot) => sum + lot.quantity, 0)
  const verified = lots.filter(lot => lot.status === 'Verified').length

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand"><span>🌱</span> AgriTrace</div>
        <p className="side-label">WORKSPACE</p>
        {['Dashboard', 'Lots', 'Quality Grading', 'Warehouse Allocation', 'Payments'].map(tab => (
          <button
            key={tab}
            className={`nav-item ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab === 'Dashboard' ? '▦' :
             tab === 'Lots' ? '▤' :
             tab === 'Quality Grading' ? '✓' :
             tab === 'Warehouse Allocation' ? '⌂' : '₹'}
            <span>{tab}</span>
          </button>
        ))}
        <div className="sidebar-footer">Transparent trade.<br />Trusted records.</div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <p className="eyebrow">AGRICULTURAL PROCUREMENT PLATFORM</p>
            <h1>{activeTab}</h1>
          </div>
          <div className="profile"><span>👤</span><div><strong>Demo User</strong><small>Project workspace</small></div></div>
        </header>

        {activeTab === 'Dashboard' && (
          <>
            <section className="welcome">
              <div>
                <p className="eyebrow light">AGRICULTURE • TRANSPARENCY • TRUST</p>
                <h2>Procurement, made clearer.</h2>
                <p>Track produce, verify quality and monitor settlements in one place.</p>
                <button className="primary-button" onClick={() => setShowForm(true)}>+ Register produce</button>
              </div>
              <div className="welcome-icon">🌾</div>
            </section>

            <section className="stats">
              <article className="stat-card"><span>Total lots</span><strong>{lots.length}</strong><small>Registered batches</small></article>
              <article className="stat-card"><span>Quantity tracked</span><strong>{totalQuantity.toLocaleString()} kg</strong><small>Across all demo lots</small></article>
              <article className="stat-card"><span>Quality verified</span><strong>{verified}</strong><small>Verified demo lots</small></article>
              <article className="stat-card"><span>Payments pending</span><strong>3</strong><small>Sample display only</small></article>
            </section>

            <section className="panel">
              <div className="panel-heading"><div><h3>Recent produce lots</h3><p>Overview of registered agricultural batches</p></div><button className="text-button" onClick={() => setActiveTab('Lots')}>View all →</button></div>
              <LotTable lots={lots.slice(0, 4)} />
            </section>
          </>
        )}

        {activeTab === 'Lots' && (
          <section className="panel">
            <div className="panel-heading"><div><h3>Produce inventory</h3><p>Track batches from registration onward</p></div><button className="primary-button" onClick={() => setShowForm(true)}>+ Register produce</button></div>
            <LotTable lots={lots} />
          </section>
        )}

        {activeTab === 'Quality Grading' && (
          <section className="panel">
            <div className="panel-heading"><div><h3>Quality inspection</h3><p>Demo records only; no real inspector is connected.</p></div></div>
            {lots.map(lot => <div className="list-row" key={lot.id}><div><strong>{lot.crop} · {lot.id}</strong><p>{lot.quantity.toLocaleString()} kg</p></div><span className={`status ${lot.status === 'Verified' ? 'good' : 'pending'}`}>{lot.grade}</span></div>)}
          </section>
        )}

        {activeTab === 'Warehouse Allocation' && (
          <section className="panel">
            <div className="panel-heading"><div><h3>Warehouse allocation</h3><p>Sample allocation preview — QpiAI Opt is not connected.</p></div></div>
            {lots.map((lot, index) => <div className="list-row" key={lot.id}><div><strong>{lot.crop} · {lot.id}</strong><p>{lot.quantity.toLocaleString()} kg available</p></div><span className="warehouse">{['Warehouse North', 'Warehouse Central', 'Warehouse South'][index % 3]}</span></div>)}
          </section>
        )}

        {activeTab === 'Payments' && (
          <section className="panel">
            <div className="panel-heading"><div><h3>Payment tracking</h3><p>Illustrative payment statuses; no real payments are processed.</p></div></div>
            {lots.map((lot, index) => <div className="list-row" key={lot.id}><div><strong>{lot.id} · {lot.crop}</strong><p>Quantity: {lot.quantity.toLocaleString()} kg</p></div><span className={`status ${index === 0 ? 'good' : 'pending'}`}>{index === 0 ? 'Demo settled' : 'Pending'}</span></div>)}
          </section>
        )}

        <footer>AgriTrace · Hackathon prototype · Sample data only</footer>
      </main>

      {showForm && (
        <div className="modal-backdrop">
          <form className="modal" onSubmit={registerLot}>
            <button type="button" className="close-button" onClick={() => setShowForm(false)}>×</button>
            <p className="eyebrow">NEW AGRICULTURAL BATCH</p>
            <h2>Register produce</h2>
            <label>Crop type
              <select value={crop} onChange={e => setCrop(e.target.value)}>
                <option>Rice</option><option>Wheat</option><option>Tomatoes</option><option>Potatoes</option><option>Onions</option>
              </select>
            </label>
            <label>Quantity (kg)
              <input type="number" min="1" required value={quantity} onChange={e => setQuantity(e.target.value)} placeholder="e.g. 1200" />
            </label>
            <button className="primary-button full-width" type="submit">Register lot</button>
          </form>
        </div>
      )}
    </div>
  )
}

function LotTable({ lots }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>LOT ID</th><th>PRODUCE</th><th>QUANTITY</th><th>QUALITY</th><th>STATUS</th></tr></thead>
        <tbody>
          {lots.map(lot => (
            <tr key={lot.id}>
              <td><strong>{lot.id}</strong></td><td>{lot.crop}</td>
              <td>{lot.quantity.toLocaleString()} kg</td><td>{lot.grade}</td>
              <td><span className={`status ${lot.status === 'Verified' ? 'good' : 'pending'}`}>{lot.status}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default App